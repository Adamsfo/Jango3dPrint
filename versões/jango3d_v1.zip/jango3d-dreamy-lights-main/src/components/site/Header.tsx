import { Link } from "@tanstack/react-router";
import { ShoppingBag, Sparkles } from "lucide-react";
import { useCart } from "@/contexts/cart-context";

export function Header() {
  const links = [
    { to: "/", label: "Início" },
    { to: "/colecao", label: "Coleção" },
    { to: "/personalizar", label: "Personalizar" },
    { to: "/sobre", label: "Sobre" },
    { to: "/contato", label: "Contato" },
  ] as const;

  const { totalItems } = useCart();

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Link to="/" className="flex items-center gap-2 font-display text-xl tracking-tight">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-accent/60 text-accent-foreground">
            <Sparkles className="h-4 w-4" />
          </span>
          JANGO<span className="text-muted-foreground">3D</span>
        </Link>
        <nav className="hidden items-center gap-8 text-sm md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="text-muted-foreground transition-colors hover:text-foreground"
              activeProps={{ className: "text-foreground" }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="relative mr-4">
          <ShoppingBag className="h-5 w-5" />
          {totalItems > 0 && <span className="absolute -right-2 -top-2 rounded-full bg-accent px-1.5 text-[10px]">{totalItems}</span>}
        </div>
        <Link
          to="/colecao"
          className="rounded-full bg-foreground px-5 py-2.5 text-xs font-medium uppercase tracking-widest text-background transition hover:bg-foreground/85"
        >
          Comprar
        </Link>
      </div>
    </header>
  );
}

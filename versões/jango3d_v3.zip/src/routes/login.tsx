import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
 const navigate = useNavigate();
 const [email,setEmail]=useState("");
 const [password,setPassword]=useState("");
 const [loading,setLoading]=useState(false);
 const [isLogin,setIsLogin]=useState(true);
 const [message,setMessage]=useState("");

 async function handleSubmit(e:any){
 e.preventDefault();
 setLoading(true);
 setMessage("");
 try {
 if(isLogin){
 const {error}= await supabase.auth.signInWithPassword({email,password});
 if(error) throw error;
 setMessage("Login realizado com sucesso!");
 navigate({to:'/'});
 } else {
 const {error}= await supabase.auth.signUp({email,password});
 if(error) throw error;
 setMessage("Cadastro realizado! Verifique seu email.");
 }
 } catch(err:any){ setMessage(err.message)}
 setLoading(false)
 }

 return <div className="min-h-screen bg-black text-white flex items-center justify-center p-6">
 <div className="w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-950 p-8">
 <h1 className="text-3xl font-bold mb-2">JANGO3D</h1>
 <p className="text-zinc-400 mb-6">Acesse sua conta</p>
 <form onSubmit={handleSubmit} className="space-y-4">
 <input className="w-full rounded-lg border border-zinc-700 bg-zinc-900 p-3" placeholder="Seu email" value={email} onChange={e=>setEmail(e.target.value)} />
 <input type="password" className="w-full rounded-lg border border-zinc-700 bg-zinc-900 p-3" placeholder="Sua senha" value={password} onChange={e=>setPassword(e.target.value)} />
 <button className="w-full rounded-lg bg-white text-black p-3 font-semibold">{loading?'Carregando...':isLogin?'Entrar':'Criar conta'}</button>
 </form>
 {message && <p className="mt-4 text-sm text-zinc-300">{message}</p>}
 <button onClick={()=>setIsLogin(!isLogin)} className="mt-4 text-sm text-zinc-400">{isLogin?'Não possui conta? Cadastre-se':'Já possui conta? Entrar'}</button>
 <div className="mt-6"><Link to="/" className="text-sm text-zinc-500">Voltar para home</Link></div>
 </div></div>
}
